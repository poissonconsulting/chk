#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang lifecycle
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
